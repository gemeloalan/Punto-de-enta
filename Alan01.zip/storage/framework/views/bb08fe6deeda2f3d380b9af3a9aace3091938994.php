<?php $__env->startSection('template_title'); ?>
    <?php echo e($brand->name ?? 'Show Brand'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Marcas</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary " href="<?php echo e(route('brands.index')); ?>"> Regresar
                                <i class="fas fa-left"></i>
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($brand->nombre); ?>

                        </div>
                        <div class="form-group">
                            <strong>Categoria:</strong>
                            <?php if(isset($brand->category->name)): ?>
                            <?php echo e($brand->category->name); ?>

                            <?php else: ?> <p class="ala">No hay Registro</p>  
                         <?php endif; ?>                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alan01\resources\views/brand/show.blade.php ENDPATH**/ ?>