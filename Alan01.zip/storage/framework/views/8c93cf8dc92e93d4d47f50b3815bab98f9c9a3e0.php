<?php $__env->startSection('template_title'); ?>
Productos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset ('css/main.css')); ?>">

<div class="card">
    <div class="card-body">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span id="card_title">
                                    <?php echo e(__('Productos')); ?>

                                </span>
                                <div class="float-right">
                                    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary btn-sm float-right"
                                        data-placement="left">

                                        <?php echo e(__('Nuevo Producto')); ?> <i class="far fa-solid fa-plus-square"></i>
                                    </a>
                                    <a href="<?php echo e(route('products.pdf')); ?>" class="btn btn-primary btn-sm float-right"
                                        data-placement="left">
                                        <i class="far fa-solid fa-file-pdf"></i>
                                    </a>

                                    
                                </div>
                            </div>
                        </div>
                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover dts">
                                    <thead class="thead">
                                        <tr>

                                            <th class="text-center">No</th>
                                            <th class="text-center">Nombre</th>
                                            <th class="text-center">Descripcion</th>
                                            <th class="text-center">Precio</th>
                                            <th class="text-center">Stock</th>
                                            <th class="text-center">Total</th>
                                            <th class="text-center">Categoria</th>
                                            <th class="text-center">Marca</th>
                                            <th class="text-center">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td class="text-center"><?php echo e(++$i); ?></td>
                                            <td class="text-center"><?php echo e($product->nombre); ?></td>
                                            <td class="text-center"><?php echo e($product->descripcion); ?></td>
                                            <td class="text-center"><?php echo e($product->precio); ?></td>
                                            <td class="text-center"><?php echo e($product->stock); ?></td>
                                            <td class="text-center"><?php echo e($product->total); ?></td>
                                            <td class="text-center">
                                                <?php if(isset($product->category->name)): ?>
                                                    
                                                <?php echo e($product->category->name); ?>

                                                <?php else: ?> <p class="ala">NO hay registro</p>
                                                <?php endif; ?>
                                            
                                            </td>
                                            <td class="text-center ">
                                                <?php if(isset($product->brand->nombre)): ?>

                                                <?php echo e($product->brand->nombre); ?>

                                                    <?php else: ?> <p class="ala">No hay registro</p>
                                                <?php endif; ?>
                                            
                                            </td>
                                            <td>
                                                <a class="btn " href="<?php echo e(route('products.show',$product->id)); ?>"><i
                                                        class="far fa-eye"></i> </a>
                                                <a class="btn " href="<?php echo e(route('products.edit',$product->id)); ?>"><i
                                                        class="far fa-edit"></i> </a>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <a href=""" class=" btn" data-toggle="modal"
                                                    data-target="#deleteMdl<?php echo e($product->id); ?>">
                                                    <i class="far fa-trash-alt"></i>
                                                </a>
                                                
                                                <!-- Modal -->
                                                <div class="modal animated zoomIn" id="deleteMdl<?php echo e($product->id); ?>"
                                                    tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog modal-lg" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title text-inspina text-primary text-center"
                                                                    id="exampleModalLabel">Realmente desea borrar el
                                                                    producto <span class="borrado"><?php echo e($product->nombre); ?></span></h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form action="<?php echo e(route('products.destroy', $product)); ?>"
                                                                    role="form" method="POST" id="createProductFrm">
                                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                                    <div class="modal-footer">
                                                                        <button type="button"
                                                                            class="btn btn-secondary mr-1"
                                                                            data-dismiss="modal">Cancelar</button>
                                                                        <button type="submit" href="#"
                                                                            class="btn btn-primary">Borrar
                                                                            Producto</button>
                                                                    </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    </form>
                                                </div>


                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php echo $products->links(); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alan01\resources\views/product/index.blade.php ENDPATH**/ ?>