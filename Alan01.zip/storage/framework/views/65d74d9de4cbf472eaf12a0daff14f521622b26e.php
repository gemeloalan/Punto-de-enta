<link href="<?php echo e(public_path('css/sb-admin-2.min.css')); ?>" rel="stylesheet" type="text">
<style>
    .uno{
        text-align: center;
        color: black;
    }
</style>
<h1 class="uno">Lista de Productos</h1>
        <table class="table table-striped table-bordered table-hover dts">
            <thead class="thead">
                <tr>

                    <th class="text-center">Nombre</th>
                    <th class="text-center">Descripcion</th>
                    <th class="text-center">Precio</th>
                    <th class="text-center">Stock</th>
                    <th class="text-center">Total</th>
                    <th class="text-center">Categoria</th>
                    <th class="text-center">Marca</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($product->nombre); ?></td>
                    <td class="text-center"><?php echo e($product->descripcion); ?></td>
                    <td class="text-center"><?php echo e($product->precio); ?></td>
                    <td class="text-center"><?php echo e($product->stock); ?></td>
                    <td class="text-center"><?php echo e($product->total); ?></td>
                    <td class="text-center">
                        <?php if(isset($product->category->name)): ?>
                            
                        <?php echo e($product->category->name); ?>

                        <?php else: ?> <p class="ala">NO hay registro</p>
                        <?php endif; ?>
                    
                    </td>
                    <td class="text-center">
                        <?php if(isset($product->brand->nombre)): ?>

                        <?php echo e($product->brand->nombre); ?>

                            <?php else: ?> <p class="ala">No hay registro</p>
                        <?php endif; ?>
                    
                    </td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
  <?php /**PATH C:\xampp\htdocs\Alan01\resources\views/product/pdf.blade.php ENDPATH**/ ?>