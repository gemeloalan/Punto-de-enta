<?php $__env->startSection('template_title'); ?>
    Cliente
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <span id="card_title">
                                        <?php echo e(__('Cliente')); ?>

                                    </span>
                                     <div class="float-right">
                                        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                          <?php echo e(__('Nuevo Usuario')); ?> <i class="far fa-solid fa-plus-square"></i>
                                        </a>
                                        <a href="<?php echo e(route('customers.pdf')); ?>" class="btn btn-primary btn-sm float-right"
                                        data-placement="left">
                                        <i class="far fa-solid fa-file-pdf"></i>
                                    </a>
                                      </div>
                                </div>
                            </div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e($message); ?></p>
                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered     table-hover dts">
                                        <thead class="thead">
                                            <tr>
            
                                                <th class="text-center">No</th>
                                                    <th class="text-center">Nombre</th>
                                                    <th class="text-center">Correo</th>
                                                    <th class="text-center">Telefono</th>
                                                    <th class="text-center">Direccion</th>
                                                    <th class="text-center">Estado  </th>
                                                    <th class="text-center">Municipio  </th>
                                                <th class="text-center">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
            
                                                    <td class="text-center"><?php echo e(++$i); ?></td>
                                                        <td class="text-center"><?php echo e($customer->nombre); ?></td>
                                                        <td class="text-center"><?php echo e($customer->correo); ?></td>
                                                        <td class="text-center"><?php echo e($customer->telefono); ?></td>
                                                        <td class="text-center"><?php echo e($customer->direccion); ?></td>


                                                        <td class="text-center ">
                                                            <?php if(isset( $customer->state->nombre)): ?>
                                                            <?php echo e($customer->state->nombre); ?>

                                                            <?php else: ?> <p class="ala">No hay registro</p>
                                                            <?php endif; ?>
                                                            
                                                        
                                                        </td>
                                                        <td class="text-center ">
                                                            <?php if(isset($customer->municipality->nombre)): ?>
                                                              <?php echo e($customer->municipality->nombre); ?>

                                                              <?php else: ?> <p class="ala">NO hay registro</p>  
                                                            <?php endif; ?>
                                                            
                                                        
                                                        </td>
                                                        
                                                    <td class="text-center col-sm-3">
                                                            <a class="btn  " href="<?php echo e(route('customers.show',$customer->id)); ?>"><i class="far fa-eye"></i> </a>
                                                            <a class="btn " href="<?php echo e(route('customers.edit',$customer->id)); ?>"><i class="far fa-edit"></i> </a>
                                                           <a  class="btn" data-toggle="modal" data-target="#deleteMdl<?php echo e($customer->id); ?>" "> <i class="far fa-trash-alt "></i></a>
                                                    </td>
                                                    <div class="modal animated zoomIn" id="deleteMdl<?php echo e($customer->id); ?>"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-lg" role="document">
                                                        <div class="modal-content">
                                                        <div class="modal-header">
                                                         <h5 class="modal-title text-inspina text-primary text-center" id="exampleModalLabel">Realmente desea borrar al cliente<span class="borrado"> <?php echo e($customer->nombre); ?></span></h5>
                                                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                           <span aria-hidden="true">&times;</span>
                                                         </button>
                                                        </div>
                                                        <div class="modal-body">
                                                         <form action="<?php echo e(route('customers.destroy', $customer)); ?>" role="form" method="POST" id="createProductFrm">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                        <div class="modal-footer">
                                                           <button type="button" class="btn btn-secondary mr-1" data-dismiss="modal">Cancelar</button>
                                                           <button type="submit" href="#" class="btn btn-primary">Borrar Producto</button>
                                                         </div>
                                                        </div>
                                                        </div>
                                                        </div>
            
                                                        </form>
                                                        </div>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php echo $customers->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alan01\resources\views/customer/index.blade.php ENDPATH**/ ?>