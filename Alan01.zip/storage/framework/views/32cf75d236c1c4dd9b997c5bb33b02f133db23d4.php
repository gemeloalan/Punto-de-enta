
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Maracas')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                
                

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <?php if(Auth::check()): ?>
                    

                    
                        
                    
                    <ul class="navbar-nav me-auto">
                       
                            <a class="nav-link noma" href="<?php echo e(route('categories.index')); ?>"><?php echo e(__('Categorias')); ?>/</a>
                            <a class="nav-link noma" href="<?php echo e(route('brands.index')); ?>"><?php echo e(__('Marcas')); ?>/</a>
                            <a class="nav-link noma" href="<?php echo e(route('products.index')); ?>"><?php echo e(__('Productos')); ?>/</a>
                            <a class="nav-link noma" href="<?php echo e(route('states.index')); ?>"><?php echo e(__('Estados')); ?>/</a>
                            <a class="nav-link noma" href="<?php echo e(route('municipalities.index')); ?>"><?php echo e(__('Municipios')); ?>/</a>
                            <a class="nav-link noma" href="<?php echo e(route('customers.index')); ?>"><?php echo e(__('Clientes')); ?></a>
                        
                        
                    </ul>

                    <?php endif; ?>
                    

                    <!-- Right Side Of Navbar -->
                    
                </div>
            </div>
        </nav>

        
            <?php echo $__env->yieldContent('content'); ?>
        
            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
           <!-- Footer -->
           <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span class="maquina ">Copyright &copy; Alan Manuel 2022</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

</body>

</html>
<?php /**PATH C:\xampp\htdocs\Alan01\resources\views/layouts/app.blade.php ENDPATH**/ ?>