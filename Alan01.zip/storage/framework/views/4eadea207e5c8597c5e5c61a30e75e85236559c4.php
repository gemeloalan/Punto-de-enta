<ul class="navbar-nav ms-auto">
    <!-- Authentication Links -->
    <?php if(auth()->guard()->guest()): ?>
        <?php if(Route::has('login')): ?>
            <li class="nav-item menu">
                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Inicia Sesión')); ?></a>
            </li>
        <?php endif; ?>

        <?php if(Route::has('register')): ?>
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrate')); ?></a>
            </li>
        <?php endif; ?>
    <?php else: ?>
        <li class="nav-item menu dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                <?php echo e(Auth::user()->name); ?>

            </a>

            <div class="dropdown-menu dropdown-menu-end salir-login " aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                    <?php echo e(__('Salir')); ?>  <i class="far fa-arrow-alt-circle-right">  </i>
                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </li>
    <?php endif; ?>
</ul>
<link rel="stylesheet" href="<?php echo e(asset ('css/main.css')); ?>">
<?php /**PATH C:\xampp\htdocs\Alan01\resources\views/layouts/menu.blade.php ENDPATH**/ ?>