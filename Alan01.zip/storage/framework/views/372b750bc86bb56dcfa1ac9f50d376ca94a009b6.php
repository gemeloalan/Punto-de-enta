<?php $__env->startSection('template_title'); ?>
    Categorias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-8">
        <div class="card-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <span id="card_title">
                                        <?php echo e(__('Categorias')); ?>

                                    </span>
                                     <div class="float-right">
                                        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                          <?php echo e(__('Nueva Categoria')); ?>

                                        </a>
                                      </div>
                                </div>
                            </div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e($message); ?></p>
                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover dts">
                                        <thead class="thead">
                                            <tr>
                                                <th class="text-center">ID</th>
                                                
                                                    <th class="text-center">Nombre</th>
                                                <th class="text-center">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-center"><?php echo e(++$i); ?></td>
                                                    
                                                        <td class="text-center"><?php echo e($category->name); ?></td>
                                                    <td class="text-center">
                                                        <a class="btn  " href="<?php echo e(route('categories.show',$category->id)); ?>"><i class="far fa-eye"></i> </a>
                                                        <a class="btn " href="<?php echo e(route('categories.edit',$category->id)); ?>"><i class="far fa-edit"></i> </a>
                                                        <a href="" class="btn" data-target="#deleteMdl<?php echo e($category->id); ?>"  data-toggle="modal" href="<?php echo e(route('categories.destroy', $category->id)); ?>"><i class="far fa-trash-alt"></i></a>
                                                    </td>
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal animated zoomIn" id="deleteMdl<?php echo e($category->id); ?>"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog modal-lg" role="document">
                                                            <div class="modal-content"> 
                                                            <div class="modal-header">
                                                             <h5 class="modal-title text-inspina text-primary text-center" id="exampleModalLabel">Realmente desea borrar la categoria:<span class="borrado"> <?php echo e($category->name); ?></span></h5>
                                                             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                               <span aria-hidden="true">&times;</span>
                                                             </button>
                                                            </div>
                                                            <div class="modal-body">
                                                             <form action="<?php echo e(route('categories.destroy', $category)); ?>" role="form" method="POST" id="createProductFrm">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                            <div class="modal-footer">
                                                               <button type="button" class="btn btn-secondary mr-1" data-dismiss="modal">Cancelar</button>
                                                               <button type="submit" href="#" class="btn btn-primary">Borrar Producto</button>
                                                             </div>
                                                            </div>
                                                            </div>
                                                            </div>
                                                            
                                                            </form>
                                                            </div>
                                                           
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php echo $categories->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alan01\resources\views/category/index.blade.php ENDPATH**/ ?>