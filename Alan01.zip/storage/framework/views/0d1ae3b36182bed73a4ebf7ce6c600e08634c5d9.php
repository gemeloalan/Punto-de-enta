<?php $__env->startSection('template_title'); ?>
    <?php echo e($customer->name ?? 'Show Customer'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Clientes
                            </span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('customers.index')); ?>"> Regresar</a>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="form-group">
                            <strong>Estado:</strong>
                           
                                <?php if(isset( $customer->state->nombre)): ?>
                                <?php echo e($customer->state->nombre); ?>

                                <?php else: ?> <p class="ala">No hay registro</p>
                                <?php endif; ?>
                                
                            
                            
                        </div>
                        <div class="form-group">
                            <strong>Municipio:</strong>
                            <?php echo e($customer->municipality->nombre); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($customer->nombre); ?>

                        </div>
                        <div class="form-group">
                            <strong>Correo:</strong>
                            <?php echo e($customer->correo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono:</strong>
                            <?php echo e($customer->telefono); ?>

                        </div>
                        <div class="form-group">
                            <strong>Direccion:</strong>
                            <?php echo e($customer->direccion); ?>

                        </div>
                      

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Alan01\resources\views/customer/show.blade.php ENDPATH**/ ?>